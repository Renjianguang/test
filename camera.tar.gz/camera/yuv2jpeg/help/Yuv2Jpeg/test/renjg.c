#include <stdio.h>

int renjg_test(int a, int b){
    printf("a + b = %d",a+b);
    return a + b;
}
